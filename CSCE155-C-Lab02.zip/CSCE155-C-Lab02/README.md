# Computer Science I
## Lab 2.0 - Basics

This lab introduces you to the basics of a C program
including fundamental variable types, arithmetic operators,
standard input/output, and non-interactive input.

This is a lab used in Computer Science I (CSCE 155E, CSCE 155H) in the [Department of Computer Science & Engineering](https://cse.unl.edu) at the [University of Nebraska-Lincoln](https://unl.edu).
